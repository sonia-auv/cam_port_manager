var searchData=
[
  ['streammode_5522',['StreamMode',['../_acquisition___c_8c.html#a5b53090612b0845fc9b0fa2ac6cb791f',1,'Acquisition_C.c']]]
];
