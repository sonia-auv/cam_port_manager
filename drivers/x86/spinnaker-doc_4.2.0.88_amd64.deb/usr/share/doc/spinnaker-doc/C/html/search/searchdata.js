var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxy",
  1: "_",
  2: "abcdefgilmnpqrst",
  3: "acdgimopqrsw",
  4: "abcdefghiklmnopqrstuvw",
  5: "bqs",
  6: "_sv",
  7: "_abcdefghilmnprstuvwxy",
  8: "mns",
  9: "cdeilnqst",
  10: "bfgnpsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

