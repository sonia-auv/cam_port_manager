var searchData=
[
  ['getting_20started_7672',['Getting Started',['../index.html',1,'']]]
];
