var searchData=
[
  ['height_4879',['Height',['../struct__quick_spin.html#ab53b398e4b2b2f5b3824e90154f2ab81',1,'_quickSpin::Height()'],['../struct__spin_m_j_p_g_option.html#ab2e78c61905b4419fcc7b4cfc500fe85',1,'_spinMJPGOption::height()'],['../struct__spin_h264_option.html#ab2e78c61905b4419fcc7b4cfc500fe85',1,'_spinH264Option::height()'],['../struct__spin_a_v_i_option.html#ab2e78c61905b4419fcc7b4cfc500fe85',1,'_spinAVIOption::height()']]],
  ['heightmax_4880',['HeightMax',['../struct__quick_spin.html#a5b61dec469c7747394e3fffe374431ec',1,'_quickSpin']]],
  ['hostadapterdriverversion_4881',['HostAdapterDriverVersion',['../struct__quick_spin_t_l_interface.html#a553cbe240ccd2b387d82c0fc4beca55d',1,'_quickSpinTLInterface']]],
  ['hostadaptername_4882',['HostAdapterName',['../struct__quick_spin_t_l_interface.html#a18e9178bfec56df81239edce5354cf7d',1,'_quickSpinTLInterface']]],
  ['hostadaptervendor_4883',['HostAdapterVendor',['../struct__quick_spin_t_l_interface.html#a267a586b9717b309a2c09388ae6acedb',1,'_quickSpinTLInterface']]]
];
