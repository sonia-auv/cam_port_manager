var searchData=
[
  ['offsetx_5003',['OffsetX',['../struct__quick_spin.html#ac248515d7452777975713469c04f7465',1,'_quickSpin']]],
  ['offsety_5004',['OffsetY',['../struct__quick_spin.html#a6b5aca67ba2aa6127ed2f89240d5fc5e',1,'_quickSpin']]]
];
