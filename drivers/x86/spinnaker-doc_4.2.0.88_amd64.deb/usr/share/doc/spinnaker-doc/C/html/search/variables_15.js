var searchData=
[
  ['whiteclip_5234',['WhiteClip',['../struct__quick_spin.html#a96024ac5a89502548b62a99760391586',1,'_quickSpin']]],
  ['whiteclipselector_5235',['WhiteClipSelector',['../struct__quick_spin.html#acd76cd684e02d01d6eee7f19c48dc19b',1,'_quickSpin']]],
  ['width_5236',['width',['../struct__spin_m_j_p_g_option.html#aca34d28e3d8bcbcadb8edb4e3af24f8c',1,'_spinMJPGOption::width()'],['../struct__spin_h264_option.html#aca34d28e3d8bcbcadb8edb4e3af24f8c',1,'_spinH264Option::width()'],['../struct__spin_a_v_i_option.html#aca34d28e3d8bcbcadb8edb4e3af24f8c',1,'_spinAVIOption::width()'],['../struct__quick_spin.html#aef410a452fcccaae11219a7c9b7593dc',1,'_quickSpin::Width()']]],
  ['widthmax_5237',['WidthMax',['../struct__quick_spin.html#a3d8d85d72b194ddc27bd6503261a9bf3',1,'_quickSpin']]],
  ['windowsizeh_5238',['WindowSizeH',['../struct__quick_spin.html#af7306d809c8ccf682418ec955b19d864',1,'_quickSpin']]],
  ['windowsizew_5239',['WindowSizeW',['../struct__quick_spin.html#ab84d839dd3bcde8d48cdfdeb0dec2d41',1,'_quickSpin']]]
];
