var searchData=
[
  ['regiondestination_5022',['RegionDestination',['../struct__quick_spin.html#a727a7b4e15fb8525f32b8a2c4df04906',1,'_quickSpin']]],
  ['regionmode_5023',['RegionMode',['../struct__quick_spin.html#a1036d4da07a086334dd453c3fd7b36dd',1,'_quickSpin']]],
  ['regionselector_5024',['RegionSelector',['../struct__quick_spin.html#a96fd4329089e1995f0b7b9dda2bb718c',1,'_quickSpin']]],
  ['reserved_5025',['reserved',['../struct__spin_p_n_g_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinPNGOption::reserved()'],['../struct__spin_p_p_m_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinPPMOption::reserved()'],['../struct__spin_p_g_m_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinPGMOption::reserved()'],['../struct__spin_t_i_f_f_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinTIFFOption::reserved()'],['../struct__spin_j_p_e_g_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinJPEGOption::reserved()'],['../struct__spin_j_p_g2_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinJPG2Option::reserved()'],['../struct__spin_b_m_p_option.html#a0273ee8a01d4ca70442033afb3f2db33',1,'_spinBMPOption::reserved()'],['../struct__spin_m_j_p_g_option.html#a1cf7e25816457eb1768779e6804c062e',1,'_spinMJPGOption::reserved()'],['../struct__spin_h264_option.html#ab01f98f82ff12d8f856605033e517f05',1,'_spinH264Option::reserved()'],['../struct__spin_a_v_i_option.html#a1cf7e25816457eb1768779e6804c062e',1,'_spinAVIOption::reserved()']]],
  ['reversex_5026',['ReverseX',['../struct__quick_spin.html#a805f28c63fe9af9c2dd080514997dd3b',1,'_quickSpin']]],
  ['reversey_5027',['ReverseY',['../struct__quick_spin.html#ab5247a51b9d4e96979200a0ea64bb4ad',1,'_quickSpin']]],
  ['rgbtransformlightsource_5028',['RgbTransformLightSource',['../struct__quick_spin.html#ab13524c23949ea33a9955cedc545aae4',1,'_quickSpin']]]
];
