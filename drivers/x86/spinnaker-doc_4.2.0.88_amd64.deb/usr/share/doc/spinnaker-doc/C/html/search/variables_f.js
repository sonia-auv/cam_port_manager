var searchData=
[
  ['quality_5021',['quality',['../struct__spin_j_p_e_g_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinJPEGOption::quality()'],['../struct__spin_j_p_g2_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinJPG2Option::quality()'],['../struct__spin_m_j_p_g_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinMJPGOption::quality()']]]
];
