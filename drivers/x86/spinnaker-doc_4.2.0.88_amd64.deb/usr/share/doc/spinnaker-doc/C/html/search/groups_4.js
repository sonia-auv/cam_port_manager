var searchData=
[
  ['logging_20event_20data_20access_7648',['Logging Event Data Access',['../group___c_logging_event_data.html',1,'']]]
];
