var searchData=
[
  ['quickspin_20access_7651',['QuickSpin Access',['../group___c_quick_spin_access.html',1,'']]]
];
