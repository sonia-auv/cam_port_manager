var searchData=
[
  ['quickspin_20access_2764',['QuickSpin Access',['../group___c_quick_spin_access.html',1,'']]],
  ['quality_2765',['quality',['../struct__spin_j_p_e_g_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinJPEGOption::quality()'],['../struct__spin_j_p_g2_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinJPG2Option::quality()'],['../struct__spin_m_j_p_g_option.html#a6b9888afa18cb95420dd38f456a2f926',1,'_spinMJPGOption::quality()']]],
  ['queryinterface_2766',['QueryInterface',['../_enumeration___c_8c.html#ac78dd0b29ac326f85a8e96ebb824d432',1,'QueryInterface(spinInterface hInterface):&#160;Enumeration_C.c'],['../_enumeration___c___quick_spin_8c.html#ac78dd0b29ac326f85a8e96ebb824d432',1,'QueryInterface(spinInterface hInterface):&#160;Enumeration_C_QuickSpin.c']]],
  ['quickspinbooleannode_2767',['quickSpinBooleanNode',['../_quick_spin_defs_c_8h.html#a1ba4ffe90c37960f2a084d536d704669',1,'QuickSpinDefsC.h']]],
  ['quickspinc_2eh_2768',['QuickSpinC.h',['../_quick_spin_c_8h.html',1,'']]],
  ['quickspincommandnode_2769',['quickSpinCommandNode',['../_quick_spin_defs_c_8h.html#aaac2f5b6f9bbdbe4cbd7c8bafeb54b90',1,'QuickSpinDefsC.h']]],
  ['quickspindefsc_2eh_2770',['QuickSpinDefsC.h',['../_quick_spin_defs_c_8h.html',1,'']]],
  ['quickspinenumerationnode_2771',['quickSpinEnumerationNode',['../_quick_spin_defs_c_8h.html#a95b730c91c1a50e3bfdbae9eb528d81e',1,'QuickSpinDefsC.h']]],
  ['quickspinfloatnode_2772',['quickSpinFloatNode',['../_quick_spin_defs_c_8h.html#a04ee5bdb32afbb6c19c76976e5a188fd',1,'QuickSpinDefsC.h']]],
  ['quickspininit_2773',['quickSpinInit',['../group___c_quick_spin_access.html#ga6ff16624a552b4255485d114815b9422',1,'QuickSpinC.h']]],
  ['quickspininitex_2774',['quickSpinInitEx',['../group___c_quick_spin_access.html#ga413937d42f9d13cc3f9de423ae52fc6a',1,'QuickSpinC.h']]],
  ['quickspinintegernode_2775',['quickSpinIntegerNode',['../_quick_spin_defs_c_8h.html#afa9f28d0ddeaeffa64c799e20b66bae3',1,'QuickSpinDefsC.h']]],
  ['quickspinregisternode_2776',['quickSpinRegisterNode',['../_quick_spin_defs_c_8h.html#ad381c8ff79704502f57f40fa679c4f92',1,'QuickSpinDefsC.h']]],
  ['quickspinstringnode_2777',['quickSpinStringNode',['../_quick_spin_defs_c_8h.html#aaaf3bc03791ad1aa076f3866944b428e',1,'QuickSpinDefsC.h']]],
  ['quickspintldeviceinit_2778',['quickSpinTLDeviceInit',['../group___c_quick_spin_access.html#ga42f54a9be2bf5fca821e5992137f1434',1,'QuickSpinC.h']]],
  ['quickspintlinterfaceinit_2779',['quickSpinTLInterfaceInit',['../group___c_quick_spin_access.html#gaf6aaa9d22670f3167bf14b450afdb4ba',1,'QuickSpinC.h']]],
  ['quickspintlstreaminit_2780',['quickSpinTLStreamInit',['../group___c_quick_spin_access.html#ga04d724132bcc8eaae462aed722efc787',1,'QuickSpinC.h']]],
  ['quickspintlsysteminit_2781',['quickSpinTLSystemInit',['../group___c_quick_spin_access.html#ga8a9413b9e5e07d5da73388efcc223c39',1,'QuickSpinC.h']]]
];
