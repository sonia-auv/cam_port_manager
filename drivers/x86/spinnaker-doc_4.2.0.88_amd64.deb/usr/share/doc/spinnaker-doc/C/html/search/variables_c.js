var searchData=
[
  ['numdirections_5001',['NumDirections',['../struct__quick_spin.html#a8234ad33a4d7b16d182606fddddefd18',1,'_quickSpin']]],
  ['numimages_5002',['numImages',['../struct__user_data.html#a5b50d93121a61fabcb50c46be7583397',1,'_userData']]]
];
