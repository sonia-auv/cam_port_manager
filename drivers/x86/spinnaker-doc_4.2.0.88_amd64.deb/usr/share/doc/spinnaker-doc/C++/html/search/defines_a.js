var searchData=
[
  ['spinupdate_5fapi_10643',['SPINUPDATE_API',['../_spin_update_8h.html#a7a0ef6fe30768261d945b4603f6df5ea',1,'SpinUpdate.h']]]
];
