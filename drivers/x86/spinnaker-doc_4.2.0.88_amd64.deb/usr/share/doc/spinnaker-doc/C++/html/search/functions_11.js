var searchData=
[
  ['queryinterface_6520',['QueryInterface',['../_enumeration_8cpp.html#ac207d7d20e29c987015fe8206cfd9d2c',1,'QueryInterface(InterfacePtr pInterface):&#160;Enumeration.cpp'],['../_enumeration___quick_spin_8cpp.html#ac207d7d20e29c987015fe8206cfd9d2c',1,'QueryInterface(InterfacePtr pInterface):&#160;Enumeration_QuickSpin.cpp'],['../_gig_e_config_8cpp.html#a97bda12b3cb9c12081797616e9ad654f',1,'QueryInterface(InterfacePtr pInterface):&#160;GigEConfig.cpp']]]
];
