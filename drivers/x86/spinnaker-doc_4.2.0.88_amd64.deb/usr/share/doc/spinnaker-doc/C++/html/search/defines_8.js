var searchData=
[
  ['optional_5fargument_10641',['optional_argument',['../_stereo_acquisition_2_getopt_8h.html#acca06c0a947656bd8b395bf1084ffb72',1,'optional_argument():&#160;Getopt.h'],['../_stereo_g_p_i_o_2_getopt_8h.html#acca06c0a947656bd8b395bf1084ffb72',1,'optional_argument():&#160;Getopt.h']]]
];
