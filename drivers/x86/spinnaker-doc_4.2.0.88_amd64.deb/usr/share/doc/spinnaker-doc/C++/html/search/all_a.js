var searchData=
[
  ['jpegoption_2768',['JPEGOption',['../struct_spinnaker_1_1_j_p_e_g_option.html',1,'JPEGOption'],['../struct_spinnaker_1_1_j_p_e_g_option.html#a7c700cb726913aeba5a5c8599c89a681',1,'Spinnaker::JPEGOption::JPEGOption()']]],
  ['jpg2option_2769',['JPG2Option',['../struct_spinnaker_1_1_j_p_g2_option.html',1,'JPG2Option'],['../struct_spinnaker_1_1_j_p_g2_option.html#ae21aad589f8319069ab7bc1fab8db3dd',1,'Spinnaker::JPG2Option::JPG2Option()']]]
];
